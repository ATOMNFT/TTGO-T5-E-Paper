
<br>

<div align="center">
  
  ## Face-Test

</div>

<b>A very simple test project that displays two ASCI faces with a delay between them.</b>
<br>
<b>Download the zip file above and open the .ino in Arduino IDE.</b>

<hr>

